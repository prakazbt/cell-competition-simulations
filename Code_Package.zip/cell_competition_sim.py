#!/usr/bin/env python3
"""
Reproducible code for Figures 4 and 5 of
"Therapy-Induced Cell Competition in Cancer" (Frontiers in Oncology, Review).

Usage
-----
    pip install numpy scipy matplotlib numba pandas
    python cell_competition_sim.py --runs 100 --master-seed 20251123 --outdir results

Outputs (in --outdir): fig4_agent_based.png/.pdf, fig5_population_model.png/.pdf,
abm_summary.csv, abm_runs.csv, ode_summary.json, ode_sensitivity.csv, run_metadata.json

All numbers quoted in Section 7 and Box 1 are produced by this script.
The model is an ILLUSTRATIVE thought experiment, not fitted to data.
"""
import argparse, json, os, platform, sys, time
import numpy as np
import pandas as pd
from numba import njit
from scipy import stats
from scipy.integrate import solve_ivp

# ----------------------------------------------------------------------------
# 1. Spatial agent-based model (ABM)
# ----------------------------------------------------------------------------
L = 80                      # lattice side; L*L = 6,400 sites, fully occupied (no empty sites)
N_STEPS = 260               # one step (sweep) = L*L random asynchronous updates
PULSES = ((40, 100), (160, 220))   # drug on for steps t with start <= t < end
P_DIV = 0.5                 # base division probability multiplier: P(divide) = P_DIV * f
F_SENS, F_SENS_DRUG, F_RES = 1.0, 0.15, 0.93   # fitness values
BASE_REPL = 0.15            # baseline replacement probability at a clone boundary
SLOPE = 0.8                 # weight on fitness difference
LOSE_FACTOR = 0.5           # reduction of replacement probability when focal cell is the less fit
P_DRUG_KILL = 0.12          # extra replacement of a sensitive neighbour per update under drug
RES_FRAC0 = 0.06            # initial resistant fraction (random placement)

@njit(cache=True)
def _run_abm(grid, c, seed, n_steps, pulse_mask):
    """grid: int8 LxL (0 sensitive, 1 resistant), periodic boundaries, von Neumann
    (4-site) neighbourhood. Returns resistant fraction recorded after each step
    (index 0 = initial state) and the final grid."""
    np.random.seed(seed)
    n = grid.shape[0]
    frac = np.empty(n_steps + 1)
    frac[0] = grid.sum() / (n * n)
    for t in range(n_steps):
        drug = pulse_mask[t]
        for _ in range(n * n):
            i = np.random.randint(n); j = np.random.randint(n)
            k = np.random.randint(4)
            if k == 0:   ni, nj = (i + 1) % n, j
            elif k == 1: ni, nj = (i - 1) % n, j
            elif k == 2: ni, nj = i, (j + 1) % n
            else:        ni, nj = i, (j - 1) % n
            f = grid[i, j]; g = grid[ni, nj]
            if f == 1: ff = 0.93
            else:      ff = 0.15 if drug else 1.0
            if g == 1: fg = 0.93
            else:      fg = 0.15 if drug else 1.0
            # (i) division attempt into the chosen neighbour
            if np.random.random() < 0.5 * ff and f != g:
                if ff > fg: p = 0.15 + c * 0.8 * (ff - fg)
                else:       p = 0.15 * (1.0 - 0.5 * c)
                if p > 1.0: p = 1.0
                if np.random.random() < p:
                    grid[ni, nj] = f
                    g = f
            # (ii) drug-induced loss of a sensitive neighbour, replaced by focal type
            if drug and g == 0 and f != 0:
                if np.random.random() < 0.12:
                    grid[ni, nj] = f
        frac[t + 1] = grid.sum() / (n * n)
    return frac, grid

def pulse_mask(n_steps=N_STEPS):
    m = np.zeros(n_steps, dtype=np.bool_)
    for a, b in PULSES: m[a:b] = True
    return m

def initial_grid(seed):
    rng = np.random.default_rng(seed)
    return (rng.random((L, L)) < RES_FRAC0).astype(np.int8)

def run_ensemble(n_runs, master_seed):
    """Seed management: one SeedSequence(master_seed) spawns, per replicate, an
    initial-condition seed (SHARED by both regimes -> paired design) and one
    dynamics seed per regime (independent streams)."""
    ss = np.random.SeedSequence(master_seed).spawn(n_runs)
    out = {0.0: [], 1.0: []}; snaps = {0.0: [], 1.0: []}; seeds = []
    pm = pulse_mask()
    for r in range(n_runs):
        s_init, s_w, s_s = [int(x.generate_state(1)[0]) for x in ss[r].spawn(3)]
        seeds.append((r, s_init, s_w, s_s))
        for c, sd in ((0.0, s_w), (1.0, s_s)):
            g = initial_grid(s_init)
            fr, gf = _run_abm(g, c, sd, N_STEPS, pm)
            out[c].append(fr)
            # keep snapshot grids of the first 3 runs only (for display)
            if r < 3:
                g0 = initial_grid(s_init)
                snaps[c].append(g0)
    return {c: np.array(v) for c, v in out.items()}, seeds

def snapshot_run(c, s_init, s_dyn, times=(0, 100, 260)):
    """Re-run one replicate and store grids at selected times (for Fig 4B,C)."""
    pm = pulse_mask(); g = initial_grid(s_init); res = {0: g.copy()}
    done = 0
    for t in sorted(times):
        if t == 0: continue
        # run incrementally: re-run from scratch to t with same seed (deterministic)
        g = initial_grid(s_init)
        pm_t = pm[:t]
        _, gf = _run_abm(g, c, s_dyn, t, pm_t)
        res[t] = gf.copy()
    return res

def ci_t(x, axis=0, conf=0.95):
    n = x.shape[axis]; m = x.mean(axis); sd = x.std(axis, ddof=1)
    h = stats.t.ppf(0.5 + conf / 2, n - 1) * sd / np.sqrt(n)
    return m, sd, m - h, m + h

def boot_ci(x, n_boot=5000, seed=1, conf=0.95):
    rng = np.random.default_rng(seed)
    idx = rng.integers(0, len(x), (n_boot, len(x)))
    bm = x[idx].mean(1)
    a = (1 - conf) / 2
    return np.quantile(bm, a), np.quantile(bm, 1 - a)

def first_crossing(frac, thr):
    """first recorded time index where frac >= thr; NaN if never (right-censored)."""
    idx = np.where(frac >= thr)[0]
    return float(idx[0]) if len(idx) else np.nan

def abm_stats(ens):
    rows = []
    for t in (40, 100, 160, 220, 260):
        for c in (0.0, 1.0):
            x = ens[c][:, t]; m, sd, lo, hi = ci_t(x)
            blo, bhi = boot_ci(x)
            rows.append(dict(t=t, c=c, n=len(x), mean=m, sd=sd, ci95_t_lo=lo, ci95_t_hi=hi,
                             ci95_boot_lo=blo, ci95_boot_hi=bhi, median=np.median(x)))
    summ = pd.DataFrame(rows)
    comp = []
    for t in (40, 100, 160, 220, 260):
        a, b = ens[0.0][:, t], ens[1.0][:, t]
        d = b - a
        tt = stats.ttest_rel(b, a)
        try: w = stats.wilcoxon(b, a).pvalue
        except ValueError: w = np.nan
        dm, dsd, dlo, dhi = ci_t(d[:, None])
        comp.append(dict(t=t, mean_diff_strong_minus_weak=dm[0], ci95_lo=dlo[0], ci95_hi=dhi[0],
                         paired_t_p=tt.pvalue, wilcoxon_p=w,
                         cohen_dz=d.mean() / d.std(ddof=1) if d.std(ddof=1) > 0 else np.nan))
    for thr in (0.5, 0.9, 0.99):
        for c in (0.0, 1.0):
            tc = np.array([first_crossing(f, thr) for f in ens[c]])
            comp.append(dict(t=f'time to resistant fraction >= {thr} (c={c:g})',
                             n_reached=int(np.isfinite(tc).sum()), n_runs=len(tc),
                             median=np.nanmedian(tc) if np.isfinite(tc).any() else np.nan,
                             mean=np.nanmean(tc) if np.isfinite(tc).any() else np.nan,
                             sd=np.nanstd(tc, ddof=1) if np.isfinite(tc).sum() > 1 else np.nan))
    return summ, pd.DataFrame(comp)

# ----------------------------------------------------------------------------
# 2. Two-population ODE model (deterministic; no random seed required)
# ----------------------------------------------------------------------------
PAR = dict(rS=0.5, rR=0.3, d=0.5, K=1.0, S0=0.89, R0=0.01)

def simulate_ode(mode, T=300, par=None, lo=0.8, hi=0.9):
    """mode 'continuous' (u=1) or 'adaptive' (u->0 when N<lo, u->1 when N>=hi).
    The decision is evaluated once per day (1-day decision steps); the ODE is
    integrated between decisions with LSODA at tight tolerances."""
    p = dict(PAR); p.update(par or {})
    S, R = p['S0'], p['R0']; u = 1.0
    ts, Ss, Rs, us = [0.0], [S], [R], [u]
    for day in range(T):
        N = S + R
        if mode == 'continuous': u = 1.0
        else:
            if N < lo: u = 0.0
            elif N >= hi: u = 1.0
        def rhs(t, y):
            s, r = y; n = s + r
            return [p['rS'] * s * (1 - n / p['K']) - p['d'] * u * s,
                    p['rR'] * r * (1 - n / p['K'])]
        sol = solve_ivp(rhs, (0, 1), [S, R], method='LSODA', rtol=1e-9, atol=1e-12,
                        t_eval=np.linspace(0, 1, 11)[1:])
        for k in range(sol.y.shape[1]):
            ts.append(day + sol.t[k]); Ss.append(sol.y[0, k]); Rs.append(sol.y[1, k]); us.append(u)
        S, R = sol.y[0, -1], sol.y[1, -1]
    return np.array(ts), np.array(Ss), np.array(Rs), np.array(us)

def time_to(ts, S, R, thr=0.97, K=1.0):
    N = (S + R) / K
    # first time after the initial nadir at which N >= thr
    idx = np.where(N >= thr)[0]
    return float(ts[idx[0]]) if len(idx) else np.nan

# ----------------------------------------------------------------------------
# 3. Figures
# ----------------------------------------------------------------------------
BLUE, ORANGE = '#0072B2', '#D55E00'   # Okabe-Ito, colour-blind safe

def fig4(ens, snaps, outdir, n_runs):
    import matplotlib; matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    from matplotlib.colors import ListedColormap
    plt.rcParams.update({'font.size': 9, 'font.family': 'DejaVu Sans'})
    fig = plt.figure(figsize=(7.09, 6.0), dpi=300)      # 180 mm wide
    gt = fig.add_gridspec(1, 2, width_ratios=[2.4, 1], wspace=0.38, top=0.96, bottom=0.62)
    gs = fig.add_gridspec(2, 6, hspace=0.35, wspace=0.25, top=0.52, bottom=0.06)
    axA = fig.add_subplot(gt[0, 0]); axD = fig.add_subplot(gt[0, 1])
    tt = np.arange(N_STEPS + 1)
    for (a, b) in PULSES: axA.axvspan(a, b, color='0.88', lw=0)
    for c, col, ls, lab in ((0.0, BLUE, '--', 'Weak competition (c = 0)'),
                            (1.0, ORANGE, '-', 'Strong competition (c = 1)')):
        m, sd, lo, hi = ci_t(ens[c])
        axA.fill_between(tt, lo, hi, color=col, alpha=0.25, lw=0)
        axA.plot(tt, m, color=col, ls=ls, lw=1.8, label=lab)
    axA.set_xlim(0, N_STEPS); axA.set_ylim(0, 1.02); axA.set_xticks(range(0, 261, 50))
    axA.set_xlabel('Time (lattice sweeps)'); axA.set_ylabel('Resistant clone fraction')
    axA.text(70, 0.04, 'drug pulse 1', ha='center', fontsize=8, color='0.3')
    axA.text(190, 0.04, 'drug pulse 2', ha='center', fontsize=8, color='0.3')
    axA.legend(loc='lower right', frameon=False, fontsize=8, bbox_to_anchor=(1.0, 0.1))
    for ax in (axA, axD):
        ax.spines[['top', 'right']].set_visible(False)
    # D: distribution at t=100
    d0, d1 = ens[0.0][:, 100], ens[1.0][:, 100]
    rng = np.random.default_rng(0)
    for k, (x, col) in enumerate(((d0, BLUE), (d1, ORANGE))):
        axD.scatter(k + rng.uniform(-0.12, 0.12, len(x)), x, s=7, color=col, alpha=0.45, lw=0)
        m, _, lo, hi = ci_t(x)
        axD.errorbar(k, m, yerr=[[m - lo], [hi - m]], color='k', capsize=4, lw=1.4, marker='o', ms=4)
    axD.set_xticks([0, 1]); axD.set_xticklabels(['c = 0', 'c = 1']); axD.set_xlim(-0.6, 1.6)
    axD.set_ylim(0, 1.02); axD.set_ylabel('Resistant fraction (t = 100)')
    cmap = ListedColormap([BLUE, ORANGE])
    labs = {}
    for r, (c, name) in enumerate(((0.0, 'Weak competition (c = 0)'), (1.0, 'Strong competition (c = 1)'))):
        for k, t in enumerate((0, 100, 260)):
            ax = fig.add_subplot(gs[r, 2 * k:2 * k + 2])
            ax.imshow(snaps[c][t], cmap=cmap, vmin=0, vmax=1, interpolation='nearest')
            ax.set_xticks([]); ax.set_yticks([])
            ax.set_title(f't = {t}', fontsize=8, pad=2)
            if k == 0: ax.set_ylabel(name, fontsize=8)
            if k == 0: labs[r] = ax
    from matplotlib.patches import Patch
    fig.legend(handles=[Patch(color=BLUE, label='Sensitive'), Patch(color=ORANGE, label='Resistant')],
               loc='lower center', ncol=2, frameon=False, fontsize=8, bbox_to_anchor=(0.5, 0.0))
    for ax, s in ((axA, 'A'), (axD, 'D'), (labs[0], 'B'), (labs[1], 'C')):
        ax.annotate(s, xy=(0, 1), xycoords='axes fraction', xytext=(-30 if ax in (axA, labs[0], labs[1]) else -34, 14),
                    textcoords='offset points', fontsize=12, fontweight='bold', annotation_clip=False)
    for ext in ('png', 'pdf'):
        fig.savefig(os.path.join(outdir, f'fig4_agent_based.{ext}'), dpi=300, bbox_inches='tight')
    plt.close(fig)

def fig5(res, outdir):
    import matplotlib; matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    plt.rcParams.update({'font.size': 9, 'font.family': 'DejaVu Sans'})
    fig, axs = plt.subplots(1, 2, figsize=(7.09, 2.9), sharey=True, dpi=300)
    for ax, key, title, s in ((axs[0], 'continuous', 'Continuous maximum-tolerated dose', 'A'),
                              (axs[1], 'adaptive', 'Adaptive dosing', 'B')):
        ts, S, R, u = res[key]
        ax.stackplot(ts, S, R, colors=[BLUE, ORANGE], lw=0)
        on = u > 0.5
        # drug-on bar (run-length encoded)
        edges = np.flatnonzero(np.diff(np.r_[0, on.astype(int), 0]))
        for a, b in zip(edges[::2], edges[1::2]):
            ax.fill_between([ts[a], ts[min(b, len(ts) - 1)]], 1.04, 1.09, color='0.25', lw=0)
        ax.set_ylim(0, 1.12); ax.set_xlim(0, 300)
        ax.set_title(title, fontsize=9, loc='left'); ax.set_xlabel('Time (arbitrary units; days)')
        ax.spines[['top', 'right']].set_visible(False)
        ax.annotate(s, xy=(0, 1), xycoords='axes fraction', xytext=(-26, 18), textcoords='offset points',
                    fontsize=12, fontweight='bold', annotation_clip=False)
    axs[0].set_ylabel('Tumor burden (fraction of K)')
    from matplotlib.patches import Patch
    axs[1].legend(handles=[Patch(color=BLUE, label='Sensitive'), Patch(color=ORANGE, label='Resistant'),
                           Patch(color='0.25', label='Drug on')], loc='center right', frameon=True, facecolor='white', edgecolor='none', framealpha=1, fontsize=8)
    fig.tight_layout()
    for ext in ('png', 'pdf'):
        fig.savefig(os.path.join(outdir, f'fig5_population_model.{ext}'), dpi=300, bbox_inches='tight')
    plt.close(fig)

# ----------------------------------------------------------------------------
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--runs', type=int, default=100, help='independent replicates per regime (>=30)')
    ap.add_argument('--master-seed', type=int, default=20251123)
    ap.add_argument('--outdir', default='results')
    a = ap.parse_args()
    os.makedirs(a.outdir, exist_ok=True)
    t0 = time.time()
    # ABM
    ens, seeds = run_ensemble(a.runs, a.master_seed)
    summ, comp = abm_stats(ens)
    summ.to_csv(os.path.join(a.outdir, 'abm_summary.csv'), index=False)
    comp.to_csv(os.path.join(a.outdir, 'abm_comparisons.csv'), index=False)
    rows = []
    for (r, si, sw, ss), in zip(seeds):
        for c in (0.0, 1.0):
            f = ens[c][r]
            rows.append(dict(run=r, c=c, init_seed=si, dyn_seed=sw if c == 0 else ss,
                             **{f'frac_t{t}': f[t] for t in (40, 100, 160, 220, 260)}))
    pd.DataFrame(rows).to_csv(os.path.join(a.outdir, 'abm_runs.csv'), index=False)
    # snapshots from replicate 0 (shown as a representative run, not an average)
    r0 = seeds[0]
    snaps = {0.0: snapshot_run(0.0, r0[1], r0[2]), 1.0: snapshot_run(1.0, r0[1], r0[3])}
    fig4(ens, snaps, a.outdir, a.runs)
    # ODE
    res = {k: simulate_ode(k) for k in ('continuous', 'adaptive')}
    ode = {}
    for k, (ts, S, R, u) in res.items():
        nadir_i = int(np.argmin(S + R))
        after = np.arange(len(ts)) > nadir_i
        N = S + R
        idx = np.where((N >= 0.97) & after)[0]
        ode[k] = dict(day_burden_ge_97pct=float(ts[idx[0]]) if len(idx) else None,
                      min_burden=float(N.min()), final_resistant_fraction=float(R[-1] / N[-1]))
    json.dump(ode, open(os.path.join(a.outdir, 'ode_summary.json'), 'w'), indent=2)
    fig5(res, a.outdir)
    # ODE sensitivity: resistance cost (rR) and adaptive thresholds
    sens = []
    for rR in (0.2, 0.25, 0.3, 0.35, 0.4, 0.45):
        for (lo, hi) in ((0.8, 0.9), (0.6, 0.9), (0.5, 0.8)):
            rc = simulate_ode('continuous', par=dict(rR=rR)); ra = simulate_ode('adaptive', par=dict(rR=rR), lo=lo, hi=hi)
            def t97(x):
                ts, S, R, u = x; N = S + R; i0 = int(np.argmin(N)); ii = np.where((N >= 0.97) & (np.arange(len(N)) > i0))[0]
                return float(ts[ii[0]]) if len(ii) else np.nan
            sens.append(dict(rR=rR, lower=lo, upper=hi, t97_continuous=t97(rc), t97_adaptive=t97(ra)))
    pd.DataFrame(sens).to_csv(os.path.join(a.outdir, 'ode_sensitivity.csv'), index=False)
    json.dump(dict(python=sys.version, numpy=np.__version__, platform=platform.platform(),
                   runs=a.runs, master_seed=a.master_seed, seconds=round(time.time() - t0, 1)),
              open(os.path.join(a.outdir, 'run_metadata.json'), 'w'), indent=2)
    pd.set_option('display.width', 200)
    print(summ.round(3).to_string()); print(comp.round(4).to_string()); print(json.dumps(ode, indent=2))

if __name__ == '__main__':
    main()
