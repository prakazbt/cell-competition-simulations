#!/usr/bin/env python3
"""Redraws Figure 2 (conceptual fitness re-ranking; illustrative densities, not data)
and Figure 6 (qualitative evidence map). Usage: python redraw_figures_2_6.py results"""
import sys, os, numpy as np
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, Patch
out = sys.argv[1] if len(sys.argv) > 1 else 'results'
os.makedirs(out, exist_ok=True)
plt.rcParams.update({'font.size': 9, 'font.family': 'DejaVu Sans'})
BLUE, ORANGE = '#0072B2', '#D55E00'

# ---------------- Figure 2 ----------------
x = np.linspace(-3, 6, 600)
g = lambda m, s, a: a * np.exp(-0.5 * ((x - m) / s) ** 2)
fig, axs = plt.subplots(3, 1, figsize=(7.09, 5.2), sharex=True, dpi=300)
rows = [('A', 'Before treatment', g(2.0, 0.7, 1.0), g(0.6, 0.6, 0.18)),
        ('B', 'During treatment', g(-0.5, 0.7, 1.0), g(0.6, 0.6, 0.18)),
        ('C', 'After selection', g(-0.5, 0.7, 0.04), g(0.6, 0.6, 1.0))]
thr = 1.2
for ax, (lab, ttl, s, r) in zip(axs, rows):
    ax.fill_between(x, s, color=BLUE, alpha=0.35, lw=0); ax.plot(x, s, color=BLUE, lw=1.5)
    ax.fill_between(x, r, color=ORANGE, alpha=0.35, lw=0); ax.plot(x, r, color=ORANGE, lw=1.5)
    ax.axvline(thr, color='k', ls='--', lw=0.9)
    ax.set_yticks([]); ax.spines[['top', 'right', 'left']].set_visible(False)
    ax.text(-0.02, 1.0, lab, transform=ax.transAxes, fontsize=12, fontweight='bold', va='top', ha='right')
    ax.text(0.01, 0.95, ttl, transform=ax.transAxes, fontsize=9, fontweight='bold', va='top')
axs[0].text(2.0, 1.02, 'Sensitive', color=BLUE, ha='center'); axs[0].text(0.6, 0.24, 'Pre-existing resistant', color=ORANGE, ha='center')
axs[1].annotate('', xy=(-0.5, 0.55), xytext=(1.9, 0.55), arrowprops=dict(arrowstyle='->', lw=1.2))
axs[1].text(0.7, 0.62, 'drug lowers fitness of sensitive cells', ha='center', fontsize=8)
axs[1].text(0.6, 0.24, 'Resistant: fitness largely unchanged', color=ORANGE, ha='center', fontsize=8)
axs[2].text(0.6, 1.03, 'Resistant clone is fittest remaining population', color=ORANGE, ha='center', fontsize=8)
axs[0].text(thr + 0.05, 0.62, 'illustrative competitive threshold', fontsize=8, rotation=0)
axs[1].set_ylabel('Clone density (arbitrary units)', fontsize=8)
axs[2].set_xlabel('Fitness under current conditions (arbitrary units)')
axs[0].set_title('', fontsize=1)
fig.tight_layout(); fig.savefig(f'{out}/fig2_fitness_reranking.png', dpi=300, bbox_inches='tight'); plt.close(fig)

# ---------------- Figure 6 ----------------
cols = ['Clonal\nselection', 'Persister /\nnon-genetic\ntolerance', 'p53–Myc\nfitness', 'Hippo–YAP/\nmechanics', 'Senescence /\nSASP', 'Flower\nfingerprint']
rows6 = ['Cytotoxic chemotherapy', 'Radiotherapy /\nDNA-damaging stress', 'EGFR / MAPK-pathway TKIs', 'KRAS G12C inhibitors', 'Senolytics / senomorphics']
S, E, I, A = 'Strong', 'Emerging', 'Indirect', 'Absent'
M = [[S, E, I, I, S, E],
     [A, A, E, A, S, A],
     [S, S, A, E, E, A],
     [E, A, A, A, A, A],
     [A, A, A, A, E, A]]
style = {S: ('#08306B', 'white', None), E: ('#4A90C8', 'white', None), I: ('#C6DBEF', '#08306B', '///'), A: ('#F2F2F2', '#777777', None)}
fig, ax = plt.subplots(figsize=(7.09, 4.3), dpi=300)
for i, r in enumerate(M):
    for j, v in enumerate(r):
        fc, tc, h = style[v]
        ax.add_patch(plt.Rectangle((j + 0.06, len(M) - i - 1 + 0.08), 0.88, 0.84, fc=fc, ec='#444' if v == I else fc, lw=0.5, hatch=h))
        ax.text(j + 0.5, len(M) - i - 0.5, v, ha='center', va='center', color=tc, fontsize=8, fontweight='bold' if v in (S, E) else 'normal',
                bbox=dict(fc=fc, ec='none', pad=1.2) if h else None)
ax.set_xlim(0, 6); ax.set_ylim(0, len(M)); ax.set_xticks(np.arange(6) + 0.5); ax.set_xticklabels(cols, fontsize=8)
ax.xaxis.tick_top(); ax.set_yticks(np.arange(len(M)) + 0.5); ax.set_yticklabels(rows6[::-1], fontsize=8.5)
ax.tick_params(length=0); [s.set_visible(False) for s in ax.spines.values()]
ax.axvline(2, color='0.6', lw=0.8); 
fig.legend(handles=[Patch(fc=style[k][0], ec='#444' if k == I else style[k][0], hatch=style[k][2], label=k) for k in (S, E, I, A)],
           loc='lower center', ncol=4, frameon=False, fontsize=8, bbox_to_anchor=(0.5, 0.02))
fig.subplots_adjust(left=0.25, right=0.99, top=0.84, bottom=0.14)
fig.savefig(f'{out}/fig6_evidence_map.png', dpi=300); fig.savefig(f'{out}/fig6_evidence_map.pdf'); plt.close(fig)
import json; json.dump(dict(columns=cols, rows=rows6, matrix=M), open(f'{out}/fig6_matrix.json', 'w'), indent=1)
