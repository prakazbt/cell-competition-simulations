# Reproducible code: Therapy-Induced Cell Competition in Cancer (Frontiers in Oncology, Review)

Illustrative models only (not fitted to data). Reproduces Figures 2, 4, 5, 6, Box 1 numbers and Supplementary Table S2.

## Requirements
Python 3.10+ with: numpy, scipy, matplotlib, pandas, numba (tested: Python 3.13, NumPy 2.5.3, SciPy 1.18.1, Matplotlib 3.11.2, pandas 3.0.5, Numba 0.68.1)

    pip install numpy scipy matplotlib pandas numba

## Run
    python cell_competition_sim.py --runs 100 --master-seed 20251123 --outdir results
    python redraw_figures_2_6.py results

About 30 s on two CPU cores. `--runs` must be at least 30 for the analyses reported.

## Outputs (results/)
- fig4_agent_based.png/.pdf, fig5_population_model.png/.pdf (Figures 4 and 5)
- fig2_fitness_reranking.png, fig6_evidence_map.png/.pdf (Figures 2 and 6; Figure 6 matrix in fig6_matrix.json)
- abm_summary.csv (mean, SD, 95% CI by time and regime), abm_comparisons.csv (paired differences, times to threshold)
- abm_runs.csv (every replicate with its seeds), ode_summary.json, ode_sensitivity.csv (Supplementary Table S2), run_metadata.json

## Seed management
One master seed -> numpy SeedSequence.spawn(n_runs). Each replicate gets an initial-condition seed shared by both regimes (paired design) and one independent dynamics seed per regime. Results are exactly reproducible with the same master seed.

## Notes
The agent-based model was reconstructed from the specification in Box 1 (original code unavailable); interpretive choices are listed in Box 1 and in the correction report. The two-population model is deterministic (no seeds).
